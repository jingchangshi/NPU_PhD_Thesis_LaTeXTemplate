New-Item -ItemType Directory -Force -Path output
New-Item -ItemType Directory -Force -Path output/frontmatter
xelatex --output-directory=output -aux-directory=output document.tex;
bibtex output/document.aux;
xelatex --output-directory=output -aux-directory=output document.tex;
xelatex --output-directory=output -aux-directory=output document.tex;
