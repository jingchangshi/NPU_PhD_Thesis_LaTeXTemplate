from os.path import join, realpath, dirname
from pybtex.database import parse_file

bib_fdir = dirname(realpath(__file__))

bib_fname = "reference_raw.bib"
bib_fpath = join(bib_fdir, bib_fname)
bib_data = parse_file(bib_fpath, encoding='utf-8')

key_list = []
for entry in bib_data.entries.values():
    key_list.append(entry.key)
    field_keys_list = list(entry.fields.keys())
    # Handle &
    if ('journal' in field_keys_list):
        journal = entry.fields['journal']
    else:
        journal = ''
    # {\&} is invalid. Use \&
    if ('{\&}' in journal):
        entry.fields['journal'] = journal.replace('{\&}', '&')
key_list.sort()

bib_new_fname = 'reference.bib'
bib_new_fpath = join(bib_fdir, bib_new_fname)
bib_new_f = open(bib_new_fpath, 'w', encoding='utf-8')
for i in range(len(key_list)):
    bib_new_f.writelines(bib_data.entries[key_list[i]].to_string('bibtex'))
bib_new_f.close()
print("%s is generated"%(bib_new_fpath))

